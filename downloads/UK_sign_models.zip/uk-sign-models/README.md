# Procedural UK sign models

Self-contained GLB 2.0 files with embedded PNG faces, grey 3 mm aluminium backs/edges and 76 mm galvanised posts. Units: metres; +Y up; +Z front; ground-contact origin. Lowest plate edge is 2.1 m above the origin. Models use approximate dimensions/artwork and a fallback font, not certified DfT drawings or an exact Transport typeface. Diagram 609 is specifically a mini-roundabout; any warning sign is distinct. No paid API or third-party model pack was used.

Front faces use standard nonmetallic PBR, not physically certified retroreflective rendering. GLB validation checks header/chunks, buffer bounds, embedded PNG, finite mesh coordinates, indices, nondegenerate triangles and winding. Appearance and KN5/game import require separate inspection.

Regenerate with: `python export_sign_models.py --output /path/to/models`. Front artwork is reused from road_signs.sign_texture. See UK_SIGN_REFERENCES.md for authoritative source links, verification limitations and asset/font rights considerations.
