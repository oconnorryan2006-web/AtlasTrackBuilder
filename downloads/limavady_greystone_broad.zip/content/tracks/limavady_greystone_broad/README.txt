ATLAS Road World Studio Export
===================
Track: limavady_greystone_broad  |  Length: 0.26 km  |  Width: 6.5 m

Generated KN5 track package - no Blender or ksEditor conversion needed.
Load and drive it in Assetto Corsa to verify collision and spawn behavior.
The .kn5 was generated directly with road, grass, textures and
all spawn points built in.

INSTALL
  1. Delete any previous version of this track folder.
  2. Extract the zip into your Assetto Corsa root folder:
     C:\...\steamapps\common\assettocorsa\
     (so this folder ends up in assettocorsa/content/tracks/)
  3. Launch in HOTLAP or PRACTICE mode.
     (Race needs an AI line: drive the road once in Hotlap mode,
      AC saves a fast_lane candidate into the ai/ folder.)

If the car spawns facing the wrong way, tell the tool author -
the heading convention flips in one place.

extras/ contains an optional Blender workflow for customisation.
