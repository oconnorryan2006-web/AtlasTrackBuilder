These files are OPTIONAL - the track already works out of the box.
Use them only if you want to customise the mesh in Blender and
rebuild the KN5 yourself via FBX + ksEditor.
