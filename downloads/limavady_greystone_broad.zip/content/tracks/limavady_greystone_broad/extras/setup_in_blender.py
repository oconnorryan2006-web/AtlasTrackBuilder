import bpy, math

# ATLAS Road World Studio — spawn point setup for: limavady_greystone_broad
#
# This script creates AC spawn point empties with correct settings.
# Run AFTER importing the OBJ file.
#
# The empties are placed at suggested positions — you can move them
# to wherever you want on the track. Just keep these rules:
#   - DO NOT apply rotation (no Ctrl+A > Rotation)
#   - DO NOT apply scale (no Ctrl+A > Scale)
#   - Keep them 1-2m above the road surface
#   - The arrow points in the direction the car will face

spawn_points = [
    ("AC_AB_START_L", 3.0674, 2.6800, 1.0742, 160.70),
    ("AC_AB_START_R", -3.0674, 2.6800, -1.0742, 160.70),
    ("AC_AB_FINISH_L", 75.4475, 2.2718, -243.9635, -176.34),
    ("AC_AB_FINISH_R", 68.9607, 2.2718, -243.5483, -176.34),
    ("AC_START_0", 3.3298, 2.6364, -9.5085, 160.70),
    ("AC_HOTLAP_START_0", 3.3298, 2.6364, -9.5085, 160.70),
    ("AC_PIT_0", 1.5337, 2.6800, 0.5371, 160.70),
]

created = []
for name, x, y, z, heading in spawn_points:
    empty = bpy.data.objects.new(name, None)
    bpy.context.collection.objects.link(empty)
    empty.empty_display_type = 'SINGLE_ARROW'
    empty.empty_display_size = 2.0
    empty.location = (x, y, z)
    # X=90° makes local Y point up, Z becomes forward
    # Z=heading rotates to face along the road
    empty.rotation_euler = (math.radians(90), 0, math.radians(heading))
    empty.scale = (0.01, 0.01, 0.01)
    created.append(name)
    print(f"  Created {name} at ({x:.1f}, {y:.1f}, {z:.1f}) heading={heading:.1f}")

# Show axis on empties so you can verify orientation
for obj in bpy.data.objects:
    if obj.name in created:
        obj.show_axis = True

print("\nCreated 7 spawn points for limavady_greystone_broad")
print("You can move them — just DO NOT apply rotation or scale.")
print("The arrow shows the direction the car will face.")